{ Fragmentor of the ISIDA Project

  Copyright (C) 2023 Laboratoire de Chemoinformatique, UMR 7140 CNRS (http://complex-matter.unistra.fr/equipes-de-recherche/laboratoire-de-chemoinformatique/home/)
  contact: Gilles Marcou g.marcou@unistra.fr

  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation; either version 3 of the License, or (at your
  option) any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
  for more details.

  You should have received a copy of the GNU Library General Public License
  along with this library; if not, write to the Free Software Foundation,
  Inc., 51 Franklin Street - Fifth Floor, Boston, MA 02110-1335, USA.
}
unit unitIndigo;

{$mode objfpc}{$H+}

interface
{
Unit built in order to use indigo code in Pascal.
The original function from the C API are mentionned using //, followed by their Pascal counterparts.
}

Uses
Classes,
sysutils;

const
  {$IFDEF WIN64}
    indigolib = 'indigo.dll';
  {$ENDIF}
  {$IFDEF LINUX}
    indigolib = 'libindigo.so';
  {$ENDIF}

// CEXPORT const char* indigoVersion();
function indigoVersion: PAnsiChar; cdecl; external indigolib;


// Working with sessions

//CEXPORT qword indigoAllocSessionId();
function indigoAllocSessionId: QWord; cdecl; external indigolib;
//CEXPORT void indigoSetSessionId(qword id);
procedure indigoSetSessionId(id: QWord); cdecl; external indigolib;
//CEXPORT void indigoReleaseSessionId(qword id);
procedure indigoReleaseSessionId(id: QWord); cdecl; external indigolib;
//CEXPORT const char* indigoGetLastError(void);
function indigoGetLastError: PAnsiChar; cdecl; external indigolib;
//CEXPORT int indigoFreeAllObjects();
function indigoFreeAllObjects: Integer; cdecl; external indigolib;

// Working with data

   //Molfile

//CEXPORT int indigoLoadMolecule(int source);
function indigoLoadMolecule(source: Integer): Integer; cdecl; external indigolib;
//CEXPORT int indigoLoadMoleculeFromFile(const char* filename);
function indigoLoadMoleculeFromFile(const filename: PAnsiChar): Integer; cdecl; external indigolib;
//CEXPORT int indigoLoadMoleculeFromString(const char* string);
function indigoLoadMoleculeFromString(smiles:string):integer; cdecl; external indigolib;
//CEXPORT int indigoLoadMoleculeFromBuffer(const char* buffer, int size);
function indigoLoadMoleculeFromBuffer(const buffer: PAnsiChar; size: Integer): Integer; cdecl; external indigolib;

//CEXPORT int indigoSaveMolfile(int molecule, int output);
function indigoSaveMolfile(molecule, output: Integer): Integer; cdecl; external indigolib;
//CEXPORT int indigoSaveMolfileToFile(int molecule, const char* filename);
function indigoSaveMolfileToFile(molecule: Integer; const filename: PAnsiChar): Integer; cdecl; external indigolib;
//CEXPORT const char* indigoMolfile(int molecule);
function indigoMolfile(molecule: Integer): PAnsiChar; cdecl; external indigolib;

   //RxnFile

//CEXPORT int indigoLoadReaction(int source);
function indigoLoadReaction(source: Integer): Integer; cdecl; external indigolib;
//CEXPORT int indigoLoadReactionFromFile(const char* filename);
function indigoLoadReactionFromFile(const filename: PAnsiChar): Integer; cdecl; external indigolib;
//CEXPORT int indigoLoadReactionFromString(const char* string);
function indigoLoadReactionFromString(const str: PAnsiChar): Integer; cdecl; external indigolib;
//CEXPORT int indigoLoadReactionFromBuffer(const char* buffer, int size);
function indigoLoadReactionFromBuffer(const buffer: PAnsiChar; size: Integer): Integer; cdecl; external indigolib;


//CEXPORT int indigoSaveRxnfile(int reaction, int output);
function indigoSaveRxnfile(reaction, output: Integer): Integer; cdecl; external indigolib;
//CEXPORT int indigoSaveRxnfileToFile(int reaction, const char* filename);
function indigoSaveRxnfileToFile(reaction: Integer; const filename: PAnsiChar): Integer; cdecl; external indigolib;
//CEXPORT const char* indigoRxnfile(int reaction);
function indigoRxnfile(reaction: Integer): PAnsiChar; cdecl; external indigolib;

// Aromatize

//CEXPORT int indigoAromatize(int item);
function indigoAromatize(item: Integer): Integer; cdecl; external indigolib;
//CEXPORT int indigoDearomatize(int item);
function indigoDearomatize(item: Integer): Integer; cdecl; external indigolib;

{Create a TstringList containing the sdf/rxn file aromatized.}
function AromFromTStringList(structure: TStringList): TStringList;

// Options

// CEXPORT const char* indigoGetOption(const char* name);
function indigoGetOption(const name: PAnsiChar): PAnsiChar; cdecl; external indigolib;

// CEXPORT int indigoSetOption(const char* name, const char* value);
function indigoSetOption(const name, value: PAnsiChar): Integer; cdecl; external indigolib;
// CEXPORT int indigoSetOptionInt(const char* name, int value);
function indigoSetOptionInt(const name: PAnsiChar; value: Integer): Integer; cdecl; external indigolib;
// CEXPORT int indigoSetOptionBool(const char* name, int value);
function indigoSetOptionBool(const name: PAnsiChar; value: Integer): Integer; cdecl; external indigolib;
// CEXPORT int indigoSetOptionFloat(const char* name, float value);
function indigoSetOptionFloat(const name: PAnsiChar; value: Single): Integer; cdecl; external indigolib;
// CEXPORT int indigoSetOptionColor(const char* name, float r, float g, float b);
function indigoSetOptionColor(const name: PAnsiChar; r, g, b: Single): Integer; cdecl; external indigolib;
// CEXPORT int indigoSetOptionXY(const char* name, int x, int y);
function indigoSetOptionXY(const name: PAnsiChar; x, y: Integer): Integer; cdecl; external indigolib;
// CEXPORT int indigoResetOptions();
function indigoResetOptions: Integer; cdecl; external indigolib;

implementation

function AromFromTStringList(structure: TStringList): TStringList;
var
  molID: integer;
  sessID: QWord;
  test, test2, test3, test4: String;
begin

  sessID := indigoAllocSessionId();
  indigoSetSessionId(sessID);
  indigoSetOptionInt('molfile-saving-mode', 2000);

  {test4 := string(indigoGetOption('molfile-saving-mode'));
  test3 := string(indigoGetLastError());
  test4 := string(indigoGetOption('molfile-saving-mode'));
  test3 := string(indigoGetLastError());}

  Result := TStringList.Create;
  if (structure[0] = '$RXN' ) then
    begin
      molid := indigoLoadReactionFromBuffer(structure.GetText, Length(structure.GetText));
      indigoAromatize(molid);

      if (string(indigoGetLastError()) = '') then
        begin
          Result.Text := StringReplace(indigoRxnfile(molid), Lineending, Lineending,
        [rfReplaceAll, rfIgnoreCase]);
        end
      else
        begin
          Result.Text := StringReplace(structure.Text, Lineending, Lineending,
        [rfReplaceAll, rfIgnoreCase]);
        end;
      //indigoSaveRxnfileToFile(molid, 'testAromIndigo2.rxn');
    end
  else
    begin
      molid := indigoLoadMoleculeFromBuffer(structure.GetText, Length(structure.GetText));
      indigoAromatize(molid);
      test3 := string(indigoGetLastError());

      if (string(indigoGetLastError()) = '') then
        begin
          Result.Text := StringReplace(indigoMolfile(molid), Lineending, Lineending,
        [rfReplaceAll, rfIgnoreCase]);
        end
      else
        begin
          Result.Text := StringReplace(structure.Text, Lineending, Lineending,
        [rfReplaceAll, rfIgnoreCase]);
        end;
    end;

  indigoFreeAllObjects();
  indigoReleaseSessionId(sessID);
end;

end.
