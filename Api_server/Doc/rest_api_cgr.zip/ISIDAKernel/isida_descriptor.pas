{ Fragmentor of the ISIDA Project

  Copyright (C) 2022 Laboratoire de Chemoinformatique, UMR 7140 CNRS (http://complex-matter.unistra.fr/equipes-de-recherche/laboratoire-de-chemoinformatique/home/)
  contact: Gilles Marcou g.marcou@unistra.fr

  This library is free software; you can redistribute it and/or modify it
  under the terms of the GNU Lesser General Public License as published by
  the Free Software Foundation; either version 3 of the License, or (at your
  option) any later version.

  This program is distributed in the hope that it will be useful, but WITHOUT
  ANY WARRANTY; without even the implied warranty of MERCHANTABILITY or
  FITNESS FOR A PARTICULAR PURPOSE. See the GNU Lesser General Public License
  for more details.

  You should have received a copy of the GNU Library General Public License
  along with this library; if not, write to the Free Software Foundation,
  Inc., 51 Franklin Street - Fifth Floor, Boston, MA 02110-1335, USA.
}
unit ISIDA_descriptor;

{$mode delphi}{$H+}

interface

uses
  Classes, SysUtils, contnrs, math;

const
     ddefault=-1E9;
type
    //Descriptor record
    PRDsc= ^RDsc;     // Un descripteur
    RDsc= record
          Idx: integer;//index
          Cnt: double;//occurence
          Nme: string;//name
    end;
    //

    { LRDsc }
    //List of descriptors
    PLRDsc= ^LRDsc;
    LRDsc= class(TList)   // LRDsc Liste record descriptors (vecteur de descripteur)
    private
           fsorted: boolean;
           fprp: double;
           fiprp: integer;
           function GetRDsc(Index: integer): RDsc;
           procedure SetRDsc(Index: integer; Value: RDsc);
    public
          constructor Create;
          destructor Destroy; override;
          procedure Clear; override;
          procedure DoSort;
          property Objects[Index: integer]: RDsc read GetRDsc write SetRDsc;
          property sorted: boolean read fsorted write fsorted;
          property prp: double read fprp write fprp;
          property iprp: integer read fiprp write fiprp;
          function Add(Item:RDsc): integer;
          function FindRDscIdx(Idx: integer): PRDsc;
          procedure Delete(Index: integer);
          function Remove(Item: Pointer): integer;
          procedure RemoveIdx(Idx: integer);
          procedure Insert(Index: integer; itm: RDsc);
          function FindRDscNme(Nme: string): PRDsc;
          function Duplicate: LRDsc;
          procedure Rescale(r: double);
          procedure addition(mol: LRDsc);
          procedure ReadLNSVM(var sline: string);
          function WriteSVM(): string;
          function WriteLNSVM(): string;
    end;

    { LRSMFv2 }

    PLRSMFv2= ^LRSMFv2;     // Matrice de descripteur.
    LRSMFv2= class(TObjectList)
    private
           fmetric: integer;
           fnorm: integer;
           fsigma: double;
           fsizemax: integer;//length of the larget LRDsc contained
           function ReadHdr(hfle: string): LRDsc; overload;
           function ReadHdr(Lines: TStringList): LRDsc; overload;
    public
          constructor Create;
          destructor Destroy; override;
          procedure Clear; override;
          property metric: integer read fmetric write fmetric;  // quand on défini on choisi quelle calcul de similarité faire
          property norm: integer read fnorm write fnorm;
          property sigma: double read fsigma write fsigma;
          procedure ReadSMFv1(sfle, hfle: string);
          //column=descriptor value, prop value in separate file
          procedure ReadSMFv2(sfle, hfle: string);
          //colum i=idx of desc. column i+1=desc. value, prop value in separate file
          procedure ReadSVM(sfle, hfle: string);
          procedure WriteSVM(sfle, hfle: string);
          //"idx:value" descriptor, 1st column=prop. value
          procedure ReadSMFv1SL(sfle: string; header: TStringList);
          //column=descriptor value, prop value in separate file
          procedure ReadSMFv2SL(sfle: string; header: TStringList);
          //colum i=idx of desc. column i+1=desc. value, prop value in separate file
          procedure ReadSVMSL(sfle: string; SLheader: TStringList);
          //"idx:value" descriptor, 1st column=prop. value
          function CompareElements(Index1, Index2: integer): double;       //calculs de similarité.
          function CompareElementsToExt(Idx:integer; DscL: LRDsc): double;
          function SMFv2toStrList(): TStringList;
          function GetSizeMax(bInit:boolean): integer;
          procedure Shuffle;
    end;
    //
    function CompareDscL(P1, P2: Pointer): integer;//Compare descriptors according to their index
    function EuclidianDscL(DscL1, DscL2: LRDsc): double;//Euclidian metric
    function DotProdDscL(DscL1, DscL2: LRDsc): double;//Scalar Product
    function TanDscL(DscL1, DscL2: LRDsc): double;//Tanimoto
    function TanDscLA(DscL1, DscL2: LRDsc; alpha: double): double;//Tanimoto
    function RBF(DscL1,DscL2: LRDsc; sigma: double): double;//RBF=exp(-|x1-x2|^2/(2*sigma^2))
    function CosKern(DscL1,DscL2:LRDsc):Double;
    function CosKernA(DscL1,DscL2:LRDsc; sigma: double):Double;
    function TverskyDscL(DscL1, DscL2: LRDsc; alpha: double): double;//Tversky
    function AddDscL(DscL1, DscL2: LRDsc): LRDsc;
    procedure ScalProdDscL(DscL1: LRDsc; d: double);
implementation

function CompareDscL(P1, P2: Pointer): integer;
var
   LP1, LP2: PRDsc;
begin
     LP1:=P1;
     LP2:=P2;
     if (LP1^.Idx > LP2^.Idx) then Result:=1
     else if (LP1^.Idx < LP2^.Idx) then Result:=-1
     else if (LP1^.Idx = LP2^.Idx) then Result:=0;
end;

function EuclidianDscL(DscL1, DscL2: LRDsc): double;
var
   i,j: integer;
   pitem1, pitem2: PRDsc;
   deflt: PRDsc;
begin
     //sort the descriptors list if necessary -for efficiency
     if (DscL1.sorted=false) then DscL1.DoSort;
     if (DscL2.sorted=false) then DscL2.DoSort;
     //Initialize
     Result:=0;
     i:=0;
     j:=0;
     New(deflt);
     deflt^.Cnt:=0;
     deflt^.Idx:=-1;
     deflt^.Nme:='UNK';
     pitem1:=deflt;
     pitem2:=deflt;
     //Apply euclidian metric: sqrt{sum_i (x_i-y_i)^2}
          //writeln('.'+IntToStr(DscL1.Count)+' '+IntToStr(DscL2.Count));
     while ((i<DscL1.Count) or (j<DscL2.Count)) do
     begin
          //writeln(IntToStr(i)+' '+IntToStr(j));
          if (i<DscL1.Count) then pitem1:=DscL1.Items[i]
          else pitem1:=deflt;
          if (j<DscL2.Count) then pitem2:=DscL2.Items[j]
          else pitem2:=deflt;
          if ((pitem1^.Idx>=0) and (pitem2^.Idx>=0)) then
          begin
               if (pitem1^.Idx<pitem2^.Idx) then// or ((i<DscL1.Count) and (j>=DscL2.Count))) then
               begin
                    //write(FloatToStr(pitem1^.Cnt)+' ');
                    Result:=Result+Sqr(pitem1^.Cnt);
                    Inc(i);
               end else
               if (pitem1^.Idx>pitem2^.Idx) then// or ((j<DscL2.Count) and (i>=DscL1.Count))) then
               begin
                    Result:=Result+Sqr(pitem2^.Cnt);
                    Inc(j);
               end else
               if (pitem1^.Idx=pitem2^.Idx) then
               begin
                    Result:=Result+Sqr(pitem1^.Cnt-pitem2^.Cnt);
                    Inc(i);
                    Inc(j);
               end;
          end else
          if (pitem1^.Idx>=0) then
          begin
               Result:=Result+Sqr(pitem1^.Cnt);
               Inc(i);
          end else
          if (pitem2^.Idx>=0) then
          begin
               Result:=Result+Sqr(pitem2^.Cnt);
               Inc(j);
          end;
     end;
     dispose(deflt);
     Result:=Sqrt(Result);
end;

function DotProdDscL(DscL1, DscL2: LRDsc): double;
var
   i,j: integer;
   pitem1, pitem2: PRDsc;
   deflt: PRDsc;
begin
     //sort the descriptors list if necessary -for efficiency
     if (DscL1.sorted=false) then DscL1.DoSort;
     if (DscL2.sorted=false) then DscL2.DoSort;
     //Initialize
     Result:=0;
     i:=0;
     j:=0;
     New(deflt);
     deflt^.Cnt:=0;
     deflt^.Idx:=-1;
     deflt^.Nme:='UNK';
     pitem1:=deflt;
     pitem2:=deflt;
     //Apply dot product: sum_i (x_i*y_i)}
     while ((i<DscL1.Count) or (j<DscL2.Count)) do
     begin
          if (i<DscL1.Count) then pitem1:=DscL1.Items[i]
          else pitem1:=deflt;
          if (j<DscL2.Count) then pitem2:=DscL2.Items[j]
          else pitem2:=deflt;
          if ((pitem1^.Idx>=0) and (pitem2^.Idx>=0)) then
          begin
               if (pitem1^.Idx<pitem2^.Idx) then// or ((i<DscL1.Count) and (j>=DscL2.Count))) then
               begin
                    Inc(i);
               end else
               if (pitem1^.Idx>pitem2^.Idx) then// or ((j<DscL2.Count) and (i>=DscL1.Count))) then
               begin
                    Inc(j);
               end else
               if (pitem1^.Idx=pitem2^.Idx) then
               begin
                    Result:=Result+pitem1^.Cnt*pitem2^.Cnt;
                    Inc(i);
                    Inc(j);
               end;
          end else
          if (pitem1^.Idx>=0) then
          begin
               Inc(i);
          end else
          if (pitem2^.Idx>=0) then
          begin
               Inc(j);
          end;
     end;
     dispose(deflt);
end;

function TanDscL(DscL1, DscL2: LRDsc): double;
var
   i,j: integer;
   pitem1, pitem2: PRDsc;
   deflt: PRDsc;
   d12,d11,d22: double;
begin
     d12:=0;
     d11:=0;
     d22:=0;
     //sort the descriptors list if necessary -for efficiency
     if (DscL1.sorted=false) then DscL1.DoSort;
     if (DscL2.sorted=false) then DscL2.DoSort;
     //Initialize
     Result:=0;
     i:=0;
     j:=0;
     New(deflt);
     deflt^.Cnt:=0;
     deflt^.Idx:=-1;
     deflt^.Nme:='UNK';
     pitem1:=deflt;
     pitem2:=deflt;
     while ((i<DscL1.Count) or (j<DscL2.Count)) do
     begin
          if (i<DscL1.Count) then pitem1:=DscL1.Items[i]
          else pitem1:=deflt;
          if (j<DscL2.Count) then pitem2:=DscL2.Items[j]
          else pitem2:=deflt;
          if ((pitem1^.Idx>=0) and (pitem2^.Idx>=0)) then
          begin
               if (pitem1^.Idx<pitem2^.Idx) then// or ((i<DscL1.Count) and (j>=DscL2.Count))) then
               begin
                    d11:=d11+pitem1^.Cnt*pitem1^.Cnt;
                    Inc(i);
               end else
               if (pitem1^.Idx>pitem2^.Idx) then// or ((j<DscL2.Count) and (i>=DscL1.Count))) then
               begin
                    d22:=d22+pitem2^.Cnt*pitem2^.Cnt;
                    Inc(j);
               end else
               if (pitem1^.Idx=pitem2^.Idx) then
               begin
                    d11:=d11+pitem1^.Cnt*pitem1^.Cnt;
                    d22:=d22+pitem2^.Cnt*pitem2^.Cnt;
                    d12:=d12+pitem1^.Cnt*pitem2^.Cnt;
                    Inc(i);
                    Inc(j);
               end;
          end else
          if (pitem1^.Idx>=0) then
          begin
               d11:=d11+pitem1^.Cnt*pitem1^.Cnt;
               Inc(i);
          end else
          if (pitem2^.Idx>=0) then
          begin
               d22:=d22+pitem2^.Cnt*pitem2^.Cnt;
               Inc(j);
          end;
     end;
     dispose(deflt);
     Result:=d12/(d11+d22-d12);
end;
{var
   d1d2,d1d1,d2d2: double;
begin
     d1d2:=DotProdDscL(DscL1,DscL2);
     d1d1:=DotProdDscL(DscL1,DscL1);
     d2d2:=DotProdDscL(DscL2,DscL2);
     Result:=d1d2/(d1d1+d2d2-d1d2);
end;}

function TanDscLA(DscL1, DscL2: LRDsc; alpha: double): double;
begin
     Result:=power(TanDscL(Dscl1,DscL2),alpha);
end;

function RBF(DscL1, DscL2: LRDsc; sigma: double): double;
var
   //tmpDscL: LRDsc;
   d: double;
begin
     //tmpDscL:=DscL2.Duplicate;
     //tmpDscL.Rescale(-1);
     //tmpDscL.addition(DscL1);
     d:=EuclidianDscL(DscL1,DscL2);
     Result:=exp(-sqr(d)/(2*sqr(sigma)));
     //FreeAndNil(tmpDscL);
end;

function CosKern(DscL1, DscL2: LRDsc): Double;
var
   d,n1,n2:Double;
begin
     d:=DotProdDscL(DscL1,Dscl2);
     //writeln(FloatToStr(d));
     n1:=DotProdDscL(DscL1,DscL1);
     //ScalProdDscL(DscL1,n1);
     //writeln(FloatToStr(n1));
     n2:=DotProdDscL(DscL2,DscL2);
     //ScalProdDscL(DscL2,n2);
     //writeln(FloatToStr(n2));
     Result:=(d/sqrt(n1*n2)+1)/2;
end;

function CosKernA(DscL1, DscL2: LRDsc; sigma: double): Double;
begin
     Result:=power(CosKern(DscL1,DscL2),sigma);
end;

function TverskyDscL(DscL1, DscL2: LRDsc; alpha: double): double;
var
  i, j: integer;
  pitem1, pitem2: PRDsc;
  deflt: PRDsc;
  cand, query, cross: double;
begin
   {Asymmetric score, making the difference btw. features in query (FIRST) absent from candidate: missing
   supplementary features in candidate not seen in query, population difference of common features and common feature count
   sort the descriptors list if necessary -for efficiency}
  if (DscL1.sorted = False) then
    DscL1.DoSort;
  if (DscL2.sorted = False) then
    DscL2.DoSort;

  Result := 0;
  i := 0;
  j := 0;
  cand := 0.0;
  query := 0.0;
  cross := 0.0;
  New(deflt);
  deflt^.Cnt := 0;
  deflt^.Idx := -1;
  pitem1 := deflt;
  pitem2 := deflt;
  while ((i < DscL1.Count) or (j < DscL2.Count)) do
  begin
    if (i < DscL1.Count) then
      pitem1 := DscL1.Items[i]
    else
      pitem1 := deflt;
    if (j < DscL2.Count) then
      pitem2 := DscL2.Items[j]
    else
      pitem2 := deflt;
    if ((pitem1^.Idx >= 0) and (pitem2^.Idx >= 0)) then
    begin
      if (pitem1^.Idx < pitem2^.Idx) then
      begin
        {This feature is present in query, but not in candidate}
        query := query + Sqr(pitem1^.Cnt);
        Inc(i);
      end
      else
      if (pitem1^.Idx > pitem2^.Idx) then
      begin
        {This feature is found in the candidate, not in the query}
        cand := cand + Sqr(pitem2^.Cnt);
        Inc(j);
      end
      else if (pitem1^.Idx = pitem2^.Idx) then
      begin
        {This element is common}
        cross := cross + pitem1^.Cnt * pitem2^.Cnt;
        Inc(i);
        Inc(j);
      end;
    end
    else if (pitem1^.Idx >= 0) then
    begin
      {This feature is present in query, but not in candidate}
      query := query + Sqr(pitem1^.Cnt);
      Inc(i);
    end
    else if (pitem2^.Idx >= 0) then
    begin
      {This feature is found in the candidate, not in the query}
      cand := cand + Sqr(pitem2^.Cnt);
      Inc(j);
    end;
  end;
  dispose(deflt);
  query := alpha * query + (1 - alpha) * cand + cross;
  if (query = 0.0) then
    query := 1;
  Result := 1 - cross / query;
end;

function AddDscL(DscL1, DscL2: LRDsc): LRDsc;
begin
     Result:=DscL1.Duplicate;
     Result.addition(DscL2);
end;

procedure ScalProdDscL(DscL1: LRDsc; d: double);
var
   i: integer;
   pitem: PRDsc;
begin
     for i:=0 to DscL1.Count-1 do
     begin
          pitem:=DscL1.Items[i];
          pitem^.Cnt:=pitem^.Cnt*d;
     end;
end;

{ LRDsc }

function LRDsc.GetRDsc(Index: integer): RDsc;
var
   pitem: PRDsc;
begin
     pitem:=Items[Index];
     Result:=pitem^;
end;

procedure LRDsc.SetRDsc(Index: integer; Value: RDsc);
var
   pitem: PRDsc;
begin
     pitem:=Items[Index];
     dispose(pitem);
     new(pitem);
     pitem^ := Value;
     Items[Index]:=pitem;
end;

constructor LRDsc.Create;
begin
     fsorted:=false;
     fprp:=ddefault;
     inherited Create;
end;

destructor LRDsc.Destroy;
begin
     Clear;
     inherited Destroy;
end;

procedure LRDsc.Clear;
var
   pitem: PRDsc;
   i: integer;
begin
     fsorted:=false;
     fprp:=ddefault;
     for i:=0 to Count-1 do
     begin
          pitem:=Items[i];
          dispose(pitem);
          pitem:=nil;
     end;
     inherited Clear;
end;

procedure LRDsc.DoSort;
begin
     sorted:=true;
     Sort(CompareDscL);
end;

function LRDsc.Add(Item: RDsc): integer;
var
   pitem: PRDsc;
begin
     new(pitem);
     pitem^:=Item;
     Result:= inherited Add(pitem);
end;

function LRDsc.FindRDscIdx(Idx: integer): PRDsc;
var
   pitem: PRDsc;
   i, itmp: integer;
begin
     Result:=nil;
     i:=0;
     itmp:=-1;
     while((i<Count) and (itmp<>Idx)) do
     begin
          pitem:=Items[i];
          itmp:=pitem^.Idx;
          inc(i);
     end;
     if (itmp=Idx) then Result:=pitem;
end;

function LRDsc.FindRDscNme(Nme: string): PRDsc;
var
   pitem: PRDsc;
   i: integer;
   stmp: string;
begin
     Result:=nil;
     i:=0;
     stmp:='UNK';
     while((i<Count) and (stmp<>Nme)) do
     begin
          pitem:=Items[i];
          stmp:=pitem^.Nme;
          inc(i);
     end;
     if(stmp=Nme) then Result:=pitem;
end;

function LRDsc.Duplicate: LRDsc;
var
   i: integer;
   item: RDsc;
begin
     Result:=LRDsc.Create;
     Result.prp:=fprp;
     for i:=0 to Count-1 do
     begin
          item:=Objects[i];
          Result.Add(item);
     end;
end;

procedure LRDsc.Rescale(r: double);
var
   i: integer;
   pitem: PRDsc;
begin
     for i:=0 to Count-1 do
     begin
          pitem:=PRDsc(Items[i]);
          pitem^.Cnt:=r*pitem^.Cnt;
     end;
end;

procedure LRDsc.addition(mol: LRDsc);
var
   i1, i2, iup: integer;
   dsc1, dsc2, tmpdsc: RDsc;
   noend: boolean;
begin
     i2:=0;
     dsc2:=mol.Objects[i2];
     iup:=Count-1;
     noend:=true;
     for i1:=0 to iup do
     begin
          dsc1:=Objects[i1];
          while ((dsc1.Idx > dsc2.Idx) and (noend)) do
          begin
               tmpdsc.Idx:=dsc2.Idx;
               tmpdsc.Nme:=dsc2.Nme;
               tmpdsc.Cnt:=dsc2.Cnt;
               Add(tmpdsc);
               inc(i2);
               if (i2<mol.Count) then
                  dsc2:=mol.Objects[i2]
               else
                   noend:=false;
          end;
          if (dsc1.Idx = dsc2.Idx) then
          begin
               dsc1.Cnt:=dsc1.Cnt+dsc2.Cnt;
               Objects[i1]:=dsc1;
               inc(i2);
               if (i2<mol.Count) then
                  dsc2:=mol.Objects[i2]
               else
                   noend:=false;
          end;
     end;
     for i1:=i2 to mol.Count-1 do
     begin
          dsc2:=mol.Objects[i1];
          tmpdsc.Idx:=dsc2.Idx;
          tmpdsc.Nme:=dsc2.Nme;
          tmpdsc.Cnt:=dsc2.Cnt;
          Add(tmpdsc);
     end;
     DoSort;
end;

procedure LRDsc.ReadLNSVM(var sline: string);
var
   line, tuple: TStringList;
   i: integer;
   item: RDsc;
begin
     line:=TStringList.Create();
     tuple:=TStringList.Create();
     line.Delimiter:=' ';
     tuple.Delimiter:=':';
     line.DelimitedText:=sline;
     //
     if not (line[0]='?') then
        prp:=StrToFloat(line[0]);
     //
     for i:=1 to line.count-1 do begin
         tuple.DelimitedText:=line[i];
         item.Idx:=StrToInt(tuple[0]);
         item.Cnt:=StrToFloat(tuple[1]);
         item.Nme:='Dsc'+tuple[0];
         Add(item);
     end;
     FreeAndNil(Line);
     FreeAndNil(tuple);
end;

function LRDsc.WriteSVM: string;
var
   i: integer;
begin
     Result:='';
     if (prp<>ddefault) then
     begin
          Result:=FloatToStr(prp)
     end else
         {$IfDef SVMWITHZERO}Result:='0';{$EndIf}
         {$IfNDef SVMWITHZERO}Result:='?';{$EndIf}
     for i:=0 to Count-2 do
         if abs(PRDsc(Items[i])^.Cnt)>1E-18 then
           Result:=Result+' '+IntToStr(PRDsc(Items[i])^.Idx+1)+':'+FloatToStr(PRDsc(Items[i])^.Cnt);//Why do I need +1 to fragment index? Bug in Fragmentor?
     Result:=Result+' '+IntToStr(PRDsc(Items[Count-1])^.Idx+1)+':'+FloatToStr(PRDsc(Items[Count-1])^.Cnt); //Allways print the last descriptor
end;

function LRDsc.WriteLNSVM: string;
begin
  Result:=WriteSVM+LineEnding;
end;

procedure LRDsc.Delete(Index: integer);
var
   pitem: PRDsc;
begin
     pitem:=Items[Index];
     dispose(pitem);
     inherited Delete(Index);
end;

function LRDsc.Remove(Item: Pointer): integer;
begin
     Result:=inherited Remove(Item);
     if (Item<>nil) then dispose(PRDsc(Item));
end;

procedure LRDsc.RemoveIdx(Idx: integer);
var
   pitem: PRDsc;
begin
     pitem:=FindRDscIdx(Idx);
     Remove(pitem);
end;

procedure LRDsc.Insert(Index: integer; itm: RDsc);
var
   pitem: PRDsc;
begin
     new(pitem);
     pitem^:=itm;
     inherited Insert(Index, pitem);
end;

{ LRSMFv2 }

function LRSMFv2.ReadHdr(hfle: string): LRDsc;
var
  Lines, sdata: TStringList;
  i:    integer;
  item: RDsc;
  stmp: string;
begin
  if not FileExists(hfle) then
  begin
    Exception.Create('ERROR: File ' + hfle + ' does not exist');
    halt;
  end;
  Lines  := TStringList.Create;
  Result:=ReadHdr(Lines);
  FreeAndNil(Lines);
end;

function LRSMFv2.ReadHdr(Lines: TStringList): LRDsc;
var
  sdata: TStringList;
  i:    integer;
  item: RDsc;
  stmp: string;
begin
  Result := LRDsc.Create;
  sdata  := TStringList.Create;
  sdata.Delimiter := '.';
  for i := 0 to Lines.Count - 1 do
  begin
    sdata.DelimitedText := Lines[i];
    stmp     := sdata[0];
    stmp     := sdata[1];
    item.Idx := StrToInt(sdata[0]);
    item.Nme := sdata[1];
    item.Cnt := 0;
    Result.Add(item);
  end;
  FreeAndNil(sdata);
end;

constructor LRSMFv2.Create;
begin
     inherited Create(True);
     fmetric:=1;
     fnorm:=1;
     fsigma:=1;
     fsizemax:=0;
end;

destructor LRSMFv2.Destroy;
begin
     //Clear;
     inherited Destroy;
end;

procedure LRSMFv2.Clear;
var
   i: integer;
begin
     for i:=Count-1 downto 0 do
     begin
          Remove(Items[i]);
     end;
     fsizemax:=0;
     inherited Clear;
end;

procedure LRSMFv2.ReadSMFv1(sfle, hfle: string);
var
  fle:   TextFile;
  sdata, Lines: TStringList;
  i, j:  integer;
  header, body: LRDsc;
  item:  RDsc;
  pitem: PRDsc;
begin
  header := ReadHdr(hfle);
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  sdata := TStringList.Create;
  sdata.Delimiter := ' ';
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    Add(LRDsc.Create);
    body := Last as LRDsc;
    sdata.DelimitedText := Lines[i];
    for j := 0 to sdata.Count - 1 do
    begin
      item.Idx := j + 1;
      item.Cnt := StrToInt(sdata[j]);
      pitem    := header.FindRDscIdx(item.Idx);
      if (pitem = nil) then
      begin
        Exception.Create('ERROR: Incompatible header file (' + hfle +
          ') and svm file (' + sfle + ')');
        halt;
      end;
      item.Nme := pitem^.Nme;
      body.Add(item);
    end;
  end;

  FreeAndNil(Lines);
  FreeAndNil(sdata);
  FreeAndNil(header);
end;

procedure LRSMFv2.ReadSMFv2(sfle, hfle: string);
var
  fle:   TextFile;
  sdata, Lines: TStringList;
  i, j:  integer;
  header, body: LRDsc;
  item:  RDsc;
  pitem: PRDsc;
begin
  header := ReadHdr(hfle);
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  sdata := TStringList.Create;
  sdata.Delimiter := ' ';
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    Add(LRDsc.Create);
    body := Last as LRDsc;
    sdata.DelimitedText := Lines[i];
    j    := 0;
    while (j < sdata.Count) do
    begin
      item.Idx := StrToInt(sdata[j]);
      item.Cnt := StrToInt(sdata[j + 1]);
      pitem    := header.FindRDscIdx(item.Idx);
      if (pitem = nil) then
      begin
        Exception.Create('ERROR: Incompatible header file (' + hfle +
          ') and svm file (' + sfle + ')');
        halt;
      end;
      item.Nme := pitem^.Nme;
      body.Add(item);
      j := j + 2;
    end;
  end;

  FreeAndNil(Lines);
  FreeAndNil(sdata);
  FreeAndNil(header);
end;

procedure LRSMFv2.ReadSVM(sfle, hfle: string);
var
  fle:   TextFile;
  Lines: TStringList;
  i, j:  integer;
  header, body: LRDsc;
  pitem, pitemh: PRDsc;
  str: string;
begin
  header := ReadHdr(hfle);
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    body:=LRDsc.Create;
    str:=Lines.Strings[i];
    body.ReadLNSVM(str);
    Add(body);
    for j := 0 to body.Count - 1 do
    begin
      pitem:=body.Items[j];
      pitemh    := header.FindRDscIdx(pitem^.Idx);
      if (pitemh = nil) then
      begin
        Exception.Create('ERROR: Incompatible header file (' + hfle +
          ') and svm file (' + sfle + ')');
        halt;
      end;
      pitem^.Nme := pitemh^.Nme;
    end;
  end;

  FreeAndNil(Lines);
  FreeAndNil(header);
end;

procedure LRSMFv2.WriteSVM(sfle, hfle: string);
var
  i, j, k: integer;
  mol: LRDsc;
  pdsc: PRDsc;
  Log,LFrg: TStringList;
  stmp: string;
begin
  Log:= TStringList.Create;
  LFrg:= TStringList.Create;
  LFrg.Duplicates:=dupIgnore;
  for i:=0 to Count-1 do
  begin
    mol:=LRDsc(Items[i]);
    Log.Add(mol.WriteSVM);
    for j:=0 to mol.Count-1 do
    begin
      pdsc:=PRDsc(mol.Items[j]);
      for k:=LFrg.Count to pdsc^.Idx do LFrg.Add('');//Create room to store Frg
      stmp:=IntToStr(pdsc^.Idx)+'. '+pdsc^.Nme;
      LFrg[pdsc^.Idx-1]:=stmp;
    end;
  end;
  Log.SaveToFile(sfle);
  LFrg.SaveToFile(hfle);
  FreeAndNil(Log);
  FreeAndNil(LFrg);
end;

procedure LRSMFv2.ReadSMFv1SL(sfle: string; header: TStringList);
var
  fle:  TextFile;
  sdata, Lines: TStringList;
  i, j: integer;
  body: LRDsc;
  item: RDsc;
begin
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  sdata := TStringList.Create;
  sdata.Delimiter := ' ';
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    Add(LRDsc.Create);
    body := Last as LRDsc;
    sdata.DelimitedText := Lines[i];
    for j := 0 to sdata.Count - 1 do
    begin
      item.Idx := j + 1;
      item.Cnt := StrToInt(sdata[j]);
      item.Nme := header[item.Idx - 1];
      body.Add(item);
    end;
  end;

  FreeAndNil(Lines);
  FreeAndNil(sdata);
end;

procedure LRSMFv2.ReadSMFv2SL(sfle: string; header: TStringList);
var
  fle:  TextFile;
  sdata, Lines: TStringList;
  i, j: integer;
  body: LRDsc;
  item: RDsc;
begin
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  sdata := TStringList.Create;
  sdata.Delimiter := ' ';
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    Add(LRDsc.Create);
    body := Last as LRDsc;
    sdata.DelimitedText := Lines[i];
    j    := 0;
    while (j < sdata.Count) do
    begin
      item.Idx := StrToInt(sdata[j]);
      item.Cnt := StrToInt(sdata[j + 1]);
      item.Nme := header[item.Idx - 1];
      body.Add(item);
      j := j + 2;
    end;
  end;

  FreeAndNil(Lines);
  FreeAndNil(sdata);
end;

procedure LRSMFv2.ReadSVMSL(sfle: string; SLheader: TStringList);
var
  fle:  TextFile;
  Lines: TStringList;
  i, j: integer;
  header, body: LRDsc;
  pitem, pitemh: PRDsc;
  str: string;
begin
  header:=ReadHdr(SLheader);
  if not FileExists(sfle) then
  begin
    Exception.Create('ERROR: File ' + sfle + ' does not exist');
    halt;
  end;
  Lines := TStringList.Create;
  Lines.LoadFromFile(sfle);
  for i := 0 to Lines.Count - 1 do
  begin
    body:=LRDsc.Create;
    str:=Lines.Strings[i];
    body.ReadLNSVM(str);
    Add(body);
    for j := 0 to body.Count - 1 do
    begin
         pitem:=body.Items[j];
         pitemh:=header.FindRDscIdx(pitem^.Idx);
         if pitemh=nil then
         begin
           Exception.Create('ERROR: File '+ sfle + ' incompatible with header');
           halt;
         end;
         pitem^.Nme:=pitemh^.Nme;
    end;
  end;

  FreeAndNil(Lines);
end;

function LRSMFv2.CompareElements(Index1, Index2: integer): double;
begin
     case fmetric of
     1: Result:=EuclidianDscL(LRDsc(Items[Index1]),LRDsc(Items[Index2]));
     2: Result:=TanDscLA(LRDsc(Items[Index1]),LRDsc(Items[Index2]),fsigma);
     3: Result:=RBF(LRDsc(Items[Index1]),LRDsc(Items[Index2]),fsigma);
     4: Result:=CosKernA(LRDsc(Items[Index1]),LRDsc(Items[Index2]),fsigma);
     else
         writeln('BUG: Metric '+IntToStr(fmetric)+' not implemented');
     end;
end;

function LRSMFv2.CompareElementsToExt(Idx: integer; DscL: LRDsc): double;
begin
     case fmetric of
     1: Result:=EuclidianDscL(LRDsc(Items[Idx]), DscL);
     2: Result:=TanDscLA(LRDsc(Items[Idx]),DscL,fsigma);
     3: Result:=RBF(LRDsc(Items[Idx]),DscL,fsigma);
     4: Result:=CosKernA(LRDsc(Items[Idx]),DscL,fsigma);
     else
         writeln('BUG: Metric '+IntToStr(fmetric)+' not implemented');
     end;

end;

function LRSMFv2.SMFv2toStrList(): TStringList;
var
  i, j, k: integer;
  tmpLRDsc: LRDsc;
  tmpRDsc: RDsc;
begin
  Result := TStringList.Create;
  for i := 0 to Count - 1 do
  begin
    tmpLRDsc := (Items[i] as LRDsc);
    for j := 0 to tmpLRDsc.Count - 1 do
    begin
      tmpRDsc := tmpLRDsc.Objects[j];
      if (Result.Count <= tmpRDsc.Idx) then
        for k := Result.Count to tmpRDsc.Idx do
          Result.Add('');
      Result[tmpRDsc.Idx] := tmpRDsc.Nme;
    end;
  end;
  for i:=Result.Count-1 to 0 do
      if Result[i]='' then Result.Delete(i);
end;

function LRSMFv2.GetSizeMax(bInit: boolean): integer;
//Get the length of the largest LRDsc contained in the LRSMFv2
//If bInit or the current size in 0, then the current value is computed
var
  i: integer;
begin
  if (fsizemax>0) and (bInit=False) then Result:=fsizemax
  else
    for i:=0 to Count-1 do
      if (fsizemax<LRDsc(Items[i]).Count) then fsizemax:=LRDsc(Items[i]).Count;
end;

procedure LRSMFv2.Shuffle;
var
   i,ir: integer;
   itm: LRDsc;
begin
     i:=Count;
     //writeln('Before '+IntToStr(Count));
     while i>1 do
     begin
          ir:=Random(i);
          itm:=Extract(Items[ir]) as LRDsc;
          Add(itm);
          Dec(i);
     end;
     //writeln('After '+IntToStr(Count));
end;

end.

